#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "notecli.h"


struct ll Notes_head={NULL, "",""};
struct ll *Notes_tail = &Notes_head;

struct ll *ll_append(struct ll **tail, char *name, char *data) {
    struct ll *new_node;
    new_node = (struct ll*) malloc(sizeof(struct ll));
    if (new_node == NULL) {
        return NULL;
    }
    new_node->next = NULL;
    strncpy(new_node->name, name, MAX_NAME - 1);
    strncpy(new_node->data, data, MAX_DATA - 1);
    (*tail)->next = new_node;
    *tail = new_node;
    return new_node;
}

void ll_print(struct ll *head) {
    struct ll *tmp;
    if(head->next == NULL) {
        printf ("The Notes list is empty\n");
        return;
    }
    for (tmp = head->next; tmp->next != NULL; tmp = tmp->next) {
        printf("%s\n\t%s\n", tmp->name, tmp->data);
    }
    printf("%s\n\t%s\n", tmp->name, tmp->data);

}

void help(char **);
void quit(char **);
void add(char **);
void list(char **);

struct command_st commands[] = {{"help", help}, 
                                {"quit", quit},
                                {"add", add},
                                {"list", list},
                                {"", NULL}};

void parse_command(char *command)
{

    char **ap, *argv[10], argc=0;
    unsigned int i;
    if (command == NULL || command[0] == '\0') {
        return;
    }

    for (ap = argv; (*ap = strsep(&command, " \t\n")) != NULL;) {
        if (**ap != '\0') {
            argc++;
            if (++ap >= &argv[10]) {
                    break;
            }
        }
    }
    if(argc==0) {
        return;
    }
    for(i = 0; commands[i].func; i++) {
        if(strncmp(commands[i].name, argv[0],sizeof(commands[i].name)) == 0) {
            commands[i].func(argv);
        }
    }

}
void main_loop() {
    char command[256];
    char *ret;
    while(1) {
        printf("Enter a command:");
        ret = fgets(command, sizeof(command) - 1, stdin);
        if (ret == NULL) {
            exit(0);
        }
        parse_command(command);
    }
}
void help(char **args){
    unsigned int i;
    printf("commands availible\n");
    for(i = 0; commands[i].func; i++) {
        printf("    %s\n",commands[i].name);
    }
}

void quit(char **args) {
    printf("bye\n");
    exit(0);
}

void add(char **args) {
    char data[MAX_DATA];
    char *ret;

    if (args==NULL || args[0] ==NULL || args[1] == NULL) {
        printf("usage: add NAME\n");
        return;
    }

    ret = fgets(data, MAX_DATA - 1, stdin);
    if (ret == NULL) {
        exit(0);
    }
    ll_append(&Notes_tail, args[1], data);
}

void list(char **args) {
    ll_print(&Notes_head);
}

