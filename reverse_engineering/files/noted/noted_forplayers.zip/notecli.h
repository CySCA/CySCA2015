#define MAX_NAME 100
#define MAX_DATA 1024

struct command_st {
    char name[MAX_NAME];
    void (*func)(char **);
};
struct ll {
    struct ll *next;
    char name[MAX_NAME];
    char data[MAX_DATA];
};
